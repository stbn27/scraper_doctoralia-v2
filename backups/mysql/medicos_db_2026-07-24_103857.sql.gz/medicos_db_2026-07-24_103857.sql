-- MySQL dump 10.13  Distrib 8.0.46, for Linux (x86_64)
--
-- Host: localhost    Database: medicos_db
-- ------------------------------------------------------
-- Server version	8.0.46

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `favoritos`
--

DROP TABLE IF EXISTS `favoritos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `favoritos` (
  `id` int NOT NULL AUTO_INCREMENT,
  `usuario_id` int NOT NULL,
  `medico_id` varchar(100) NOT NULL,
  `guardado_en` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `doctoralia_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_favorito` (`usuario_id`,`medico_id`),
  UNIQUE KEY `uq_favorito_usuario_medico` (`usuario_id`,`medico_id`),
  KEY `idx_favoritos_usuario` (`usuario_id`),
  CONSTRAINT `favoritos_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `favoritos`
--

LOCK TABLES `favoritos` WRITE;
/*!40000 ALTER TABLE `favoritos` DISABLE KEYS */;
/*!40000 ALTER TABLE `favoritos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `historial_busquedas`
--

DROP TABLE IF EXISTS `historial_busquedas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `historial_busquedas` (
  `id` int NOT NULL AUTO_INCREMENT,
  `usuario_id` int NOT NULL,
  `especialidad` varchar(100) DEFAULT NULL,
  `ubicacion` varchar(200) DEFAULT NULL,
  `fecha` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `consulta_texto` text,
  `filtros_json` json DEFAULT NULL,
  `origen` varchar(30) DEFAULT NULL,
  `total_resultados` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_historial_usuario_fecha` (`usuario_id`,`fecha`),
  CONSTRAINT `historial_busquedas_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=100 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `historial_busquedas`
--

LOCK TABLES `historial_busquedas` WRITE;
/*!40000 ALTER TABLE `historial_busquedas` DISABLE KEYS */;
INSERT INTO `historial_busquedas` VALUES (64,5,'dermatologo','ciudad de mexico','2026-06-21 00:33:32',NULL,'{\"orden\": \"puntuacion_desc\", \"ciudad\": \"ciudad de mexico\", \"especialidad\": \"dermatologo\", \"confiabilidad\": null, \"solo_analizados\": false}','tradicional',1135),(65,5,'dermatologo','ciudad de mexico','2026-06-21 00:36:08',NULL,'{\"orden\": \"puntuacion_desc\", \"ciudad\": \"ciudad de mexico\", \"especialidad\": \"dermatologo\", \"confiabilidad\": null, \"solo_analizados\": false}','tradicional',1135),(66,5,'dermatologo','ciudad de mexico','2026-06-21 00:36:09',NULL,'{\"orden\": \"puntuacion_desc\", \"ciudad\": \"ciudad de mexico\", \"especialidad\": \"dermatologo\", \"confiabilidad\": null, \"solo_analizados\": false}','tradicional',1135),(67,5,'dentista','Ciudad de México','2026-06-21 00:57:03',NULL,'{\"orden\": \"puntuacion_desc\", \"ciudad\": \"Ciudad de México\", \"especialidad\": \"dentista\", \"confiabilidad\": null, \"solo_analizados\": false}','tradicional',182),(68,5,'dentista','Ciudad de México','2026-06-21 00:59:57',NULL,'{\"orden\": \"puntuacion_desc\", \"ciudad\": \"Ciudad de México\", \"especialidad\": \"dentista\", \"confiabilidad\": null, \"solo_analizados\": false}','tradicional',182),(69,5,'dentista','Ciudad de México','2026-06-21 00:59:58',NULL,'{\"orden\": \"puntuacion_desc\", \"ciudad\": \"Ciudad de México\", \"especialidad\": \"dentista\", \"confiabilidad\": null, \"solo_analizados\": false}','tradicional',182),(70,5,'dentista','Ciudad de México','2026-06-21 01:00:03',NULL,'{\"orden\": \"puntuacion_desc\", \"ciudad\": \"Ciudad de México\", \"especialidad\": \"dentista\", \"confiabilidad\": null, \"solo_analizados\": false}','tradicional',182),(71,5,'dentista','Ciudad de México','2026-06-21 01:00:04',NULL,'{\"orden\": \"puntuacion_desc\", \"ciudad\": \"Ciudad de México\", \"especialidad\": \"dentista\", \"confiabilidad\": null, \"solo_analizados\": false}','tradicional',182),(72,5,'dermatologo','Azcapotzalco, Ciudad de México','2026-06-21 01:01:36',NULL,'{\"orden\": \"puntuacion_desc\", \"ciudad\": \"Azcapotzalco, Ciudad de México\", \"especialidad\": \"dermatologo\", \"confiabilidad\": null, \"solo_analizados\": false}','tradicional',1),(73,5,'dermatologo','Azcapotzalco','2026-06-21 01:02:28',NULL,'{\"orden\": \"puntuacion_desc\", \"ciudad\": \"Azcapotzalco\", \"especialidad\": \"dermatologo\", \"confiabilidad\": null, \"solo_analizados\": false}','tradicional',20),(74,5,'dermatologo','ciudad de mexico','2026-06-21 01:03:14',NULL,'{\"orden\": \"puntuacion_desc\", \"ciudad\": \"ciudad de mexico\", \"especialidad\": \"dermatologo\", \"confiabilidad\": null, \"solo_analizados\": false}','tradicional',1135),(75,5,'dermatologo','ciudad de mexico','2026-06-21 01:03:15',NULL,'{\"orden\": \"puntuacion_desc\", \"ciudad\": \"ciudad de mexico\", \"especialidad\": \"dermatologo\", \"confiabilidad\": null, \"solo_analizados\": false}','tradicional',1135),(76,5,'dermatologo','ciudad de mexico','2026-06-21 01:03:31',NULL,'{\"orden\": \"puntuacion_desc\", \"ciudad\": \"ciudad de mexico\", \"especialidad\": \"dermatologo\", \"confiabilidad\": null, \"solo_analizados\": false}','tradicional',1135),(77,5,'dermatologo','ciudad de mexico','2026-06-21 01:03:32',NULL,'{\"orden\": \"puntuacion_desc\", \"ciudad\": \"ciudad de mexico\", \"especialidad\": \"dermatologo\", \"confiabilidad\": null, \"solo_analizados\": false}','tradicional',1135),(78,5,'dermatologo','Azcapotzalco','2026-06-21 01:03:43',NULL,'{\"orden\": \"puntuacion_desc\", \"ciudad\": \"Azcapotzalco\", \"especialidad\": \"dermatologo\", \"confiabilidad\": null, \"solo_analizados\": false}','tradicional',20),(79,5,'dermatologo','Azcapotzalco, Ciudad de México','2026-06-21 01:05:26',NULL,'{\"orden\": \"puntuacion_desc\", \"ciudad\": \"Azcapotzalco, Ciudad de México\", \"especialidad\": \"dermatologo\", \"confiabilidad\": null, \"solo_analizados\": false}','tradicional',1),(80,5,'dermatologo','Oaxaca de Juarez','2026-06-21 01:11:23',NULL,'{\"orden\": \"puntuacion_desc\", \"ciudad\": \"Oaxaca de Juarez\", \"especialidad\": \"dermatologo\", \"confiabilidad\": null, \"solo_analizados\": false}','tradicional',25),(81,5,'dermatologo','Oaxaca de Juarez','2026-06-21 01:17:15',NULL,'{\"orden\": \"puntuacion_desc\", \"ciudad\": \"Oaxaca de Juarez\", \"especialidad\": \"dermatologo\", \"confiabilidad\": null, \"solo_analizados\": false}','tradicional',25),(82,5,'dermatologo','Oaxaca de Juarez','2026-06-21 01:17:17',NULL,'{\"orden\": \"puntuacion_desc\", \"ciudad\": \"Oaxaca de Juarez\", \"especialidad\": \"dermatologo\", \"confiabilidad\": null, \"solo_analizados\": false}','tradicional',25),(83,5,'dentista','Azcapotzalco, Ciudad de México','2026-06-21 01:22:47',NULL,'{\"orden\": \"puntuacion_desc\", \"ciudad\": \"Azcapotzalco, Ciudad de México\", \"especialidad\": \"dentista\", \"confiabilidad\": null, \"solo_analizados\": false}','tradicional',0),(84,5,'dentista-odontologo','Azcapotzalco, Ciudad de México','2026-06-21 01:25:14',NULL,'{\"orden\": \"puntuacion_desc\", \"ciudad\": \"Azcapotzalco, Ciudad de México\", \"especialidad\": \"dentista-odontologo\", \"confiabilidad\": null, \"solo_analizados\": false}','tradicional',0),(85,5,'dentista-odontologo','Azcapotzalco','2026-06-21 01:25:22',NULL,'{\"orden\": \"puntuacion_desc\", \"ciudad\": \"Azcapotzalco\", \"especialidad\": \"dentista-odontologo\", \"confiabilidad\": null, \"solo_analizados\": false}','tradicional',25),(86,5,'psicologo','ocotepec','2026-06-21 01:31:06',NULL,'{\"orden\": \"puntuacion_desc\", \"ciudad\": \"ocotepec\", \"especialidad\": \"psicologo\", \"confiabilidad\": null, \"solo_analizados\": false}','tradicional',154),(87,5,'psicologo','Ocotepec','2026-06-21 01:37:38',NULL,'{\"orden\": \"puntuacion_desc\", \"ciudad\": \"Ocotepec\", \"especialidad\": \"psicologo\", \"confiabilidad\": null, \"solo_analizados\": false}','tradicional',154),(88,5,'cardiologo','Ecatepec de Morelos','2026-07-01 20:06:22',NULL,'{\"orden\": \"puntuacion_desc\", \"ciudad\": \"Ecatepec de Morelos\", \"especialidad\": \"cardiologo\", \"confiabilidad\": null, \"solo_analizados\": false}','tradicional',17),(89,5,'cardiologo','Ecatepec de Morelos','2026-07-01 20:07:56',NULL,'{\"orden\": \"puntuacion_desc\", \"ciudad\": \"Ecatepec de Morelos\", \"especialidad\": \"cardiologo\", \"confiabilidad\": null, \"solo_analizados\": false}','tradicional',17),(90,5,'cardiologo','Ecatepec de Morelos','2026-07-01 20:07:57',NULL,'{\"orden\": \"puntuacion_desc\", \"ciudad\": \"Ecatepec de Morelos\", \"especialidad\": \"cardiologo\", \"confiabilidad\": null, \"solo_analizados\": false}','tradicional',17),(91,5,'cardiologo','Azcapotzalco','2026-07-02 03:55:25',NULL,'{\"orden\": \"puntuacion_desc\", \"ciudad\": \"Azcapotzalco\", \"especialidad\": \"cardiologo\", \"confiabilidad\": null, \"solo_analizados\": false}','tradicional',14),(92,5,'cardiologo','Azcapotzalco','2026-07-02 04:16:22',NULL,'{\"orden\": \"puntuacion_desc\", \"ciudad\": \"Azcapotzalco\", \"especialidad\": \"cardiologo\", \"confiabilidad\": null, \"solo_analizados\": false}','tradicional',14),(93,5,'cardiologo','Azcapotzalco','2026-07-02 04:16:23',NULL,'{\"orden\": \"puntuacion_desc\", \"ciudad\": \"Azcapotzalco\", \"especialidad\": \"cardiologo\", \"confiabilidad\": null, \"solo_analizados\": false}','tradicional',14),(98,5,'gastroenterologo','Azcapotzalco','2026-07-23 23:13:47',NULL,'{\"orden\": \"puntuacion_desc\", \"ciudad\": \"Azcapotzalco\", \"especialidad\": \"gastroenterologo\", \"confiabilidad\": null, \"solo_analizados\": false}','tradicional',16),(99,5,'gastroenterologo','Azcapotzalco','2026-07-23 23:33:19',NULL,'{\"orden\": \"puntuacion_desc\", \"ciudad\": \"Azcapotzalco\", \"especialidad\": \"gastroenterologo\", \"confiabilidad\": null, \"solo_analizados\": false}','tradicional',16);
/*!40000 ALTER TABLE `historial_busquedas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `roles` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) NOT NULL,
  `descripcion` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `nombre` (`nombre`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,'USER','Usuario estándar con acceso de lectura','2026-06-14 19:38:20'),(2,'ADMIN','Administrador con acceso completo','2026-06-14 19:38:20');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tokens_llm`
--

DROP TABLE IF EXISTS `tokens_llm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tokens_llm` (
  `id` int NOT NULL AUTO_INCREMENT,
  `usuario_id` int NOT NULL,
  `modelo` varchar(30) NOT NULL,
  `token` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `modelo` (`modelo`),
  KEY `fk_usuario_llm` (`usuario_id`),
  CONSTRAINT `fk_usuario_llm` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tokens_llm`
--

LOCK TABLES `tokens_llm` WRITE;
/*!40000 ALTER TABLE `tokens_llm` DISABLE KEYS */;
/*!40000 ALTER TABLE `tokens_llm` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuarios`
--

DROP TABLE IF EXISTS `usuarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usuarios` (
  `id` int NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `rol_id` int NOT NULL DEFAULT '1',
  `password_hash` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `nombre` varchar(100) DEFAULT NULL,
  `apellido` varchar(100) DEFAULT NULL,
  `telefono` varchar(30) DEFAULT NULL,
  `avatar_url` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  KEY `fk_usuario_rol` (`rol_id`),
  CONSTRAINT `fk_usuario_rol` FOREIGN KEY (`rol_id`) REFERENCES `roles` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuarios`
--

LOCK TABLES `usuarios` WRITE;
/*!40000 ALTER TABLE `usuarios` DISABLE KEYS */;
INSERT INTO `usuarios` VALUES (5,'jose@c.com',2,'$2b$12$k6Ltk57/5wYi67Qqdwj3VuGR1zO9nJ.XAvaaGkROxF/cECLKw2NXK','2026-06-20 18:38:52','Alberto','Esteban',NULL,'https://img.magnific.com/vector-premium/vector-dibujos-animados-perro-ilustracion-color-blanco_756535-6795.jpg?semt=ais_hybrid&w=740&q=80'),(6,'jose@a.com',1,'$2b$12$.tm3KwlnTp.IDDOz75/Zg.kIq4mMIBZnNtcC49elLYPo7KKr7qHRG','2026-07-03 21:24:17','Fernando','Esteban','2871448567',NULL),(7,'user@correo.com',1,'$2b$12$.tm3KwlnTp.IDDOz75/Zg.kIq4mMIBZnNtcC49elLYPo7KKr7qHRG','2026-07-24 16:33:50','UserTest','Hola',NULL,NULL);
/*!40000 ALTER TABLE `usuarios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuarios_direcciones`
--

DROP TABLE IF EXISTS `usuarios_direcciones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usuarios_direcciones` (
  `id` int NOT NULL AUTO_INCREMENT,
  `usuario_id` int NOT NULL,
  `alias` varchar(100) DEFAULT NULL,
  `calle` varchar(255) DEFAULT NULL,
  `colonia` varchar(150) DEFAULT NULL,
  `municipio_alcaldia` varchar(150) DEFAULT NULL,
  `ciudad` varchar(150) DEFAULT NULL,
  `ciudad_slug` varchar(150) DEFAULT NULL,
  `estado` varchar(150) DEFAULT NULL,
  `pais` varchar(100) DEFAULT 'México',
  `codigo_postal` varchar(20) DEFAULT NULL,
  `lat` decimal(10,7) DEFAULT NULL,
  `lng` decimal(10,7) DEFAULT NULL,
  `es_principal` tinyint(1) DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_direcciones_usuario` (`usuario_id`),
  KEY `idx_direcciones_ciudad_slug` (`ciudad_slug`),
  CONSTRAINT `usuarios_direcciones_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuarios_direcciones`
--

LOCK TABLES `usuarios_direcciones` WRITE;
/*!40000 ALTER TABLE `usuarios_direcciones` DISABLE KEYS */;
INSERT INTO `usuarios_direcciones` VALUES (2,5,'Casa','Av. San Pablo Xalpa No. 420',NULL,'Azcapotzalco',' Ciudad de México','-ciudad-de-mexico',' Ciudad de México','México','02128',NULL,NULL,1,'2026-06-21 00:07:30',NULL);
/*!40000 ALTER TABLE `usuarios_direcciones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary view structure for view `v_usuarios_con_rol`
--

DROP TABLE IF EXISTS `v_usuarios_con_rol`;
/*!50001 DROP VIEW IF EXISTS `v_usuarios_con_rol`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_usuarios_con_rol` AS SELECT 
 1 AS `id`,
 1 AS `email`,
 1 AS `nombre`,
 1 AS `apellido`,
 1 AS `telefono`,
 1 AS `avatar_url`,
 1 AS `rol`,
 1 AS `created_at`*/;
SET character_set_client = @saved_cs_client;

--
-- Dumping events for database 'medicos_db'
--

--
-- Dumping routines for database 'medicos_db'
--

--
-- Final view structure for view `v_usuarios_con_rol`
--

/*!50001 DROP VIEW IF EXISTS `v_usuarios_con_rol`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `v_usuarios_con_rol` AS select `u`.`id` AS `id`,`u`.`email` AS `email`,`u`.`nombre` AS `nombre`,`u`.`apellido` AS `apellido`,`u`.`telefono` AS `telefono`,`u`.`avatar_url` AS `avatar_url`,`r`.`nombre` AS `rol`,`u`.`created_at` AS `created_at` from (`usuarios` `u` join `roles` `r` on((`u`.`rol_id` = `r`.`id`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-07-24 16:39:12
